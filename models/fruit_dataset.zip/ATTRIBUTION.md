# Dataset attribution

Fruit Recognition dataset. Israr Hussain, Qianhua He, Zhuliang Chen and Wei Xie,
South China University of Technology, 2018. https://doi.org/10.5281/zenodo.1310165

Licensed CC BY 4.0: https://creativecommons.org/licenses/by/4.0/

This zip holds a subset of 1,200 photos (400 per class for apple, banana and orange),
selected deterministically by scripts/make_fruit_subset.py, converted to RGB JPEG and
resized so the longer side is at most 128 pixels. Original paths inside the Zenodo
archive and the content hashes of these resized copies are listed in manifest.json.
